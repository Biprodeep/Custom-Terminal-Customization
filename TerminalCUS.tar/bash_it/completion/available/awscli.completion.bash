[[ -x "$(which aws_completer)" ]] && complete -C "$(which aws_completer)" aws
